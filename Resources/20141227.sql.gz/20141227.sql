-- MySQL dump 10.13  Distrib 5.5.40, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db_psyana
-- ------------------------------------------------------
-- Server version	5.5.40-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_0e939a4f` (`group_id`),
  KEY `auth_group_permissions_8373b171` (`permission_id`),
  CONSTRAINT `auth_group_permission_group_id_689710a9a73b7457_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_417f1b1c` (`content_type_id`),
  CONSTRAINT `auth__content_type_id_508cf46651277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add session',5,'add_session'),(14,'Can change session',5,'change_session'),(15,'Can delete session',5,'delete_session'),(16,'Can add photo',6,'add_photo'),(17,'Can change photo',6,'change_photo'),(18,'Can delete photo',6,'delete_photo'),(19,'Can add user',7,'add_userprofile'),(20,'Can change user',7,'change_userprofile'),(21,'Can delete user',7,'delete_userprofile'),(22,'Can add office',8,'add_office'),(23,'Can change office',8,'change_office'),(24,'Can delete office',8,'delete_office'),(25,'Can add page',9,'add_page'),(26,'Can change page',9,'change_page'),(27,'Can delete page',9,'delete_page'),(28,'Can add section',10,'add_section'),(29,'Can change section',10,'change_section'),(30,'Can delete section',10,'delete_section');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_page`
--

DROP TABLE IF EXISTS `content_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `template` int(11) NOT NULL,
  `path` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_page_path_13abfb53ad2ba41b_uniq` (`path`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_page`
--

LOCK TABLES `content_page` WRITE;
/*!40000 ALTER TABLE `content_page` DISABLE KEYS */;
INSERT INTO `content_page` VALUES (1,'Inicio',2,'/'),(2,'Contact',1,'contact');
/*!40000 ALTER TABLE `content_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_photo`
--

DROP TABLE IF EXISTS `content_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `alt` varchar(255) NOT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_photo`
--

LOCK TABLES `content_photo` WRITE;
/*!40000 ALTER TABLE `content_photo` DISABLE KEYS */;
INSERT INTO `content_photo` VALUES (1,'Public/uploading/slider1_h1WTeLT.jpg','Example Title','Example alt','Centro de atención para personas con necesitades'),(2,'Public/uploading/logo_5KbG2B1.png','Main Logo','Psicologa','');
/*!40000 ALTER TABLE `content_photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_section`
--

DROP TABLE IF EXISTS `content_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template` int(11) NOT NULL,
  `skeleton` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `subtitle` varchar(200) DEFAULT NULL,
  `text` longtext NOT NULL,
  `head_photo_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `content_section_ed68dc0b` (`head_photo_id`),
  KEY `content_section_1a63c800` (`page_id`),
  CONSTRAINT `content_section_page_id_75e461acf6eec303_fk_content_page_id` FOREIGN KEY (`page_id`) REFERENCES `content_page` (`id`),
  CONSTRAINT `content_sectio_head_photo_id_24bcf900b5d662f_fk_content_photo_id` FOREIGN KEY (`head_photo_id`) REFERENCES `content_photo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_section`
--

LOCK TABLES `content_section` WRITE;
/*!40000 ALTER TABLE `content_section` DISABLE KEYS */;
INSERT INTO `content_section` VALUES (1,1,2,'Bienvenido','','Bienvenido al centro psicologico de Ana Maria Hidalgo ....',1,1),(2,1,2,'Donde estamos','','<div class=\"map\">\r\n<iframe\r\n  width=\"100%\"\r\n  height=\"200px\"\r\n  frameborder=\"0\" style=\"border:0\"\r\n  src=\"https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Carrer+de+Lope+de+Vega,+16,+07013+Palma,+Illes+Balears,+Spain&amp;output=embed\"></iframe><br><small><a href=\"https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Carrer+de+Lope+de+Vega,+16,+07013+Palma,+Illes+Balears,+Spain&amp;output=embed&amp;\">\r\n</iframe>\r\n\r\n</div>',1,1);
/*!40000 ALTER TABLE `content_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_417f1b1c` (`content_type_id`),
  KEY `django_admin_log_e8701ad4` (`user_id`),
  CONSTRAINT `django_adm_user_id_52fdd58701c5f563_fk_management_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `management_userprofile` (`id`),
  CONSTRAINT `djang_content_type_id_697914295151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2014-12-24 11:38:12','1','Example Title',1,'',6,1),(2,'2014-12-24 11:38:17','1','PsicoGym',1,'',8,1),(3,'2014-12-24 19:03:41','1','Home',1,'',9,1),(4,'2014-12-24 19:03:46','1','Home',2,'No fields changed.',9,1),(5,'2014-12-24 19:04:15','1','Home',2,'No fields changed.',9,1),(6,'2014-12-24 19:04:38','2','Contact',1,'',9,1),(7,'2014-12-26 19:34:44','1','Home',2,'Added section \"Home - Section title 1\".',9,1),(8,'2014-12-26 20:07:39','1','Home',2,'Changed template for section \"Home - Section title 1\".',9,1),(9,'2014-12-26 20:07:53','1','Home',2,'Changed template for section \"Home - Section title 1\".',9,1),(10,'2014-12-26 20:08:04','1','Home',2,'Changed template for section \"Home - Section title 1\".',9,1),(11,'2014-12-26 20:12:54','1','Home',2,'Changed skeleton for section \"Home - Section title 1\".',9,1),(12,'2014-12-26 20:13:09','1','Home',2,'Changed skeleton for section \"Home - Section title 1\".',9,1),(13,'2014-12-26 20:13:45','1','Home',2,'Added section \"Home - Section title2\".',9,1),(14,'2014-12-26 20:18:33','1','Home',2,'Added section \"Home - Section title 3\".',9,1),(15,'2014-12-26 20:18:59','1','Home',2,'Changed template for section \"Home - Section title 3\".',9,1),(16,'2014-12-26 20:21:11','1','Home',2,'Changed template and skeleton for section \"Home - Section title 1\". Changed template for section \"Home - Section title2\". Changed template and skeleton for section \"Home - Section title 3\".',9,1),(17,'2014-12-26 22:15:17','2','Main Logo',1,'',6,1),(18,'2014-12-26 22:15:35','1','PsicoGym',2,'Changed photos.',8,1),(19,'2014-12-26 22:18:00','1','PsicoGym',2,'Changed photos and logo.',8,1),(20,'2014-12-26 22:24:36','2','Main Logo',2,'Changed image.',6,1),(21,'2014-12-26 22:25:15','2','Main Logo',2,'Changed image.',6,1),(22,'2014-12-26 22:29:30','2','Main Logo',2,'Changed image.',6,1),(23,'2014-12-26 23:15:31','1','Inicio',2,'Changed title. Changed skeleton, title, subtitle and text for section \"Inicio - Bienvenido\". Changed title and subtitle for section \"Inicio - Quienes Somos\".',9,1),(24,'2014-12-26 23:32:08','1','Inicio',2,'Changed title for section \"Inicio - \".',9,1),(25,'2014-12-27 00:05:24','1','Inicio',2,'Deleted section \"Inicio - \".',9,1),(26,'2014-12-27 00:10:51','1','Inicio',2,'Changed template, title, subtitle and text for section \"Inicio - Donde estamos\".',9,1),(27,'2014-12-27 00:11:18','1','Inicio',2,'Changed template for section \"Inicio - Donde estamos\".',9,1),(28,'2014-12-27 00:13:12','1','Inicio',2,'Changed text for section \"Inicio - Donde estamos\".',9,1),(29,'2014-12-27 00:16:56','1','Inicio',2,'Changed text for section \"Inicio - Donde estamos\".',9,1),(30,'2014-12-27 00:21:44','1','Inicio',2,'Changed text for section \"Inicio - Donde estamos\".',9,1),(31,'2014-12-27 00:22:27','1','Inicio',2,'Changed text for section \"Inicio - Donde estamos\".',9,1),(32,'2014-12-27 00:24:49','1','Inicio',2,'Changed text for section \"Inicio - Donde estamos\".',9,1),(33,'2014-12-27 00:25:58','1','Inicio',2,'Changed skeleton for section \"Inicio - Donde estamos\".',9,1),(34,'2014-12-27 00:26:20','1','Inicio',2,'Changed skeleton for section \"Inicio - Bienvenido\". Changed skeleton for section \"Inicio - Donde estamos\".',9,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_45f3b1d93ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'log entry','admin','logentry'),(2,'permission','auth','permission'),(3,'group','auth','group'),(4,'content type','contenttypes','contenttype'),(5,'session','sessions','session'),(6,'photo','content','photo'),(7,'user','management','userprofile'),(8,'office','management','office'),(9,'page','content','page'),(10,'section','content','section');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2014-12-24 11:33:22'),(2,'admin','0001_initial','2014-12-24 11:33:23'),(3,'auth','0001_initial','2014-12-24 11:33:24'),(4,'sessions','0001_initial','2014-12-24 11:33:24'),(5,'content','0001_initial','2014-12-24 18:47:12'),(6,'management','0001_initial','2014-12-24 18:47:12'),(7,'content','0002_page_section','2014-12-24 18:49:03'),(8,'content','0003_auto_20141224_1854','2014-12-24 18:54:06');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('lfa7rzc9lfy79ay2hvz17qe3dpatdzbv','YTg4NjVmM2MyYjMzNDkxMWY5Y2NhYzczZGU3MzMzNjUzYmY1ZTMzYTp7fQ==','2015-01-07 11:33:53'),('lk9269ddidxe71uyp8mdgiahtl30u6sb','NDA3YTMxMmI4ODM0NDRkYjdmMzgzN2Y5YWFjYTUwZDNjOThkZjlmNTp7Il9hdXRoX3VzZXJfaGFzaCI6ImE4NjRkZDVlYzk1NmY1ZGIxNTVmMGM3YWFkN2IzMTExMjcwYWJmYmEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-01-07 11:34:18');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_office`
--

DROP TABLE IF EXISTS `management_office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_office` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `logo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `logo_id` (`logo_id`),
  CONSTRAINT `logo_id_refs_id_f151a053` FOREIGN KEY (`logo_id`) REFERENCES `content_photo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_office`
--

LOCK TABLES `management_office` WRITE;
/*!40000 ALTER TABLE `management_office` DISABLE KEYS */;
INSERT INTO `management_office` VALUES (1,'PsicoGym','+34 609 73 78 09','Lope de Vega, 16, bajos Palma De Mallorca, Spain',2);
/*!40000 ALTER TABLE `management_office` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_office_photos`
--

DROP TABLE IF EXISTS `management_office_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_office_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `office_id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `office_id` (`office_id`,`photo_id`),
  KEY `management_office_photos_203e4450` (`office_id`),
  KEY `management_office_photos_bc609657` (`photo_id`),
  CONSTRAINT `office_id_refs_id_6b256319` FOREIGN KEY (`office_id`) REFERENCES `management_office` (`id`),
  CONSTRAINT `photo_id_refs_id_79a85516` FOREIGN KEY (`photo_id`) REFERENCES `content_photo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_office_photos`
--

LOCK TABLES `management_office_photos` WRITE;
/*!40000 ALTER TABLE `management_office_photos` DISABLE KEYS */;
INSERT INTO `management_office_photos` VALUES (3,1,1);
/*!40000 ALTER TABLE `management_office_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_office_worker`
--

DROP TABLE IF EXISTS `management_office_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_office_worker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `office_id` int(11) NOT NULL,
  `userprofile_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `office_id` (`office_id`,`userprofile_id`),
  KEY `management_office_worker_203e4450` (`office_id`),
  KEY `management_office_worker_1be1924f` (`userprofile_id`),
  CONSTRAINT `office_id_refs_id_39c92946` FOREIGN KEY (`office_id`) REFERENCES `management_office` (`id`),
  CONSTRAINT `userprofile_id_refs_id_72ef3607` FOREIGN KEY (`userprofile_id`) REFERENCES `management_userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_office_worker`
--

LOCK TABLES `management_office_worker` WRITE;
/*!40000 ALTER TABLE `management_office_worker` DISABLE KEYS */;
INSERT INTO `management_office_worker` VALUES (3,1,1);
/*!40000 ALTER TABLE `management_office_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_userprofile`
--

DROP TABLE IF EXISTS `management_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `birthday` date DEFAULT NULL,
  `profile_photo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `profile_photo_id` (`profile_photo_id`),
  CONSTRAINT `profile_photo_id_refs_id_da888d22` FOREIGN KEY (`profile_photo_id`) REFERENCES `content_photo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_userprofile`
--

LOCK TABLES `management_userprofile` WRITE;
/*!40000 ALTER TABLE `management_userprofile` DISABLE KEYS */;
INSERT INTO `management_userprofile` VALUES (1,'pbkdf2_sha256$12000$dN0OaPAvirKL$E1ypPlS6dSWvMSNQ0f9RcJ4kuQ5b8SCOZWlOuZJfGBk=','2014-12-24 11:34:18',1,'dev','','','ggarri@gmail.com',1,1,'2014-12-24 11:33:36','','',NULL,NULL);
/*!40000 ALTER TABLE `management_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_userprofile_groups`
--

DROP TABLE IF EXISTS `management_userprofile_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_userprofile_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userprofile_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userprofile_id` (`userprofile_id`,`group_id`),
  KEY `management_userprofile_groups_1be1924f` (`userprofile_id`),
  KEY `management_userprofile_groups_5f412f9a` (`group_id`),
  CONSTRAINT `userprofile_id_refs_id_563eae2c` FOREIGN KEY (`userprofile_id`) REFERENCES `management_userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_userprofile_groups`
--

LOCK TABLES `management_userprofile_groups` WRITE;
/*!40000 ALTER TABLE `management_userprofile_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `management_userprofile_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_userprofile_photos`
--

DROP TABLE IF EXISTS `management_userprofile_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_userprofile_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userprofile_id` int(11) NOT NULL,
  `photo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userprofile_id` (`userprofile_id`,`photo_id`),
  KEY `management_userprofile_photos_1be1924f` (`userprofile_id`),
  KEY `management_userprofile_photos_bc609657` (`photo_id`),
  CONSTRAINT `photo_id_refs_id_3d3c9cc8` FOREIGN KEY (`photo_id`) REFERENCES `content_photo` (`id`),
  CONSTRAINT `userprofile_id_refs_id_a2b78c5c` FOREIGN KEY (`userprofile_id`) REFERENCES `management_userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_userprofile_photos`
--

LOCK TABLES `management_userprofile_photos` WRITE;
/*!40000 ALTER TABLE `management_userprofile_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `management_userprofile_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `management_userprofile_user_permissions`
--

DROP TABLE IF EXISTS `management_userprofile_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `management_userprofile_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userprofile_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userprofile_id` (`userprofile_id`,`permission_id`),
  KEY `management_userprofile_user_permissions_1be1924f` (`userprofile_id`),
  KEY `management_userprofile_user_permissions_83d7f98b` (`permission_id`),
  CONSTRAINT `userprofile_id_refs_id_e1691c4c` FOREIGN KEY (`userprofile_id`) REFERENCES `management_userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `management_userprofile_user_permissions`
--

LOCK TABLES `management_userprofile_user_permissions` WRITE;
/*!40000 ALTER TABLE `management_userprofile_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `management_userprofile_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-27  1:28:08
